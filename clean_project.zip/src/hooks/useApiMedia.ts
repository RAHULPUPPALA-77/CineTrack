import { useState, useEffect, useCallback, useRef } from "react";
import { MediaItem, TabType } from "@/types/media";
import { ALL_MEDIA } from "@/data/media";
import {
  fetchTrendingAnime,
  fetchTrendingShows,
  fetchAllTrending,
  searchAnime,
  searchShows,
} from "@/services/api";

interface UseApiMediaReturn {
  items: MediaItem[];
  loading: boolean;
  error: string | null;
  loadMore: () => void;
  hasMore: boolean;
}

export function useApiMedia(
  activeTab: TabType,
  searchQuery: string,
  selectedGenres: string[],
  watchlist: Set<number>,
  watched: Set<number>
): UseApiMediaReturn {
  const [apiItems, setApiItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const searchTimeout = useRef<ReturnType<typeof setTimeout>>();
  const prevTab = useRef(activeTab);
  const prevQuery = useRef(searchQuery);

  // Reset when tab or search changes
  useEffect(() => {
    if (activeTab !== prevTab.current || searchQuery !== prevQuery.current) {
      setApiItems([]);
      setPage(1);
      setHasMore(true);
      prevTab.current = activeTab;
      prevQuery.current = searchQuery;
    }
  }, [activeTab, searchQuery]);

  // Fetch data based on tab
  useEffect(() => {
    // For watchlist/watched, we use local data only
    if (activeTab === "watchlist" || activeTab === "watched") {
      setLoading(false);
      return;
    }

    // Debounced search
    if (searchQuery.trim()) {
      setLoading(true);
      clearTimeout(searchTimeout.current);
      searchTimeout.current = setTimeout(async () => {
        try {
          let results: MediaItem[] = [];
          if (activeTab === "anime") {
            results = await searchAnime(searchQuery);
          } else if (activeTab === "movies") {
            results = await searchShows(searchQuery);
          } else {
            const [shows, anime] = await Promise.all([
              searchShows(searchQuery),
              searchAnime(searchQuery),
            ]);
            results = [...shows, ...anime];
          }
          setApiItems(results);
          setHasMore(false);
          setError(null);
        } catch {
          setError("Search failed. Showing offline data.");
          setApiItems(ALL_MEDIA.filter(m => 
            m.title.toLowerCase().includes(searchQuery.toLowerCase())
          ));
        } finally {
          setLoading(false);
        }
      }, 500);
      return;
    }

    // Fetch trending / browse
    const fetchData = async () => {
      setLoading(true);
      try {
        let results: MediaItem[] = [];
        switch (activeTab) {
          case "anime":
            results = await fetchTrendingAnime(page);
            break;
          case "movies":
            results = await fetchTrendingShows(page - 1);
            break;
          case "trending":
            results = await fetchAllTrending();
            setHasMore(false);
            break;
          default: // "all"
            results = await fetchAllTrending();
            setHasMore(false);
            break;
        }
        setApiItems(prev => page === 1 ? results : [...prev, ...results]);
        if (results.length === 0) setHasMore(false);
        setError(null);
      } catch {
        setError("Failed to load. Showing offline data.");
        setApiItems(ALL_MEDIA);
        setHasMore(false);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    return () => clearTimeout(searchTimeout.current);
  }, [activeTab, searchQuery, page]);

  // Compute final filtered items
  const items = (() => {
    let result: MediaItem[];

    if (activeTab === "watchlist") {
      result = ALL_MEDIA.filter(m => watchlist.has(m.id));
    } else if (activeTab === "watched") {
      result = ALL_MEDIA.filter(m => watched.has(m.id));
    } else {
      result = apiItems;
    }

    if (selectedGenres.length > 0) {
      result = result.filter(m => selectedGenres.some(g => m.genre.includes(g)));
    }

    return result;
  })();

  const loadMore = useCallback(() => {
    if (!loading && hasMore) {
      setPage(p => p + 1);
    }
  }, [loading, hasMore]);

  return { items, loading, error, loadMore, hasMore };
}
