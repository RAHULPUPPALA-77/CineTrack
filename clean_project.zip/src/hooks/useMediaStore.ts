import { useState, useEffect, useCallback } from "react";

function useLocalStorageSet(key: string): [Set<number>, (id: number) => void, (id: number) => void] {
  const [items, setItems] = useState<Set<number>>(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch {
      return new Set();
    }
  });

  useEffect(() => {
    localStorage.setItem(key, JSON.stringify([...items]));
  }, [key, items]);

  const add = useCallback((id: number) => {
    setItems(prev => new Set(prev).add(id));
  }, []);

  const remove = useCallback((id: number) => {
    setItems(prev => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  }, []);

  return [items, add, remove];
}

export function useWatchlist() {
  return useLocalStorageSet("watchtracker_watchlist");
}

export function useWatched() {
  return useLocalStorageSet("watchtracker_watched");
}

export function useRatings() {
  const [ratings, setRatings] = useState<Record<number, number>>(() => {
    try {
      const stored = localStorage.getItem("watchtracker_ratings");
      return stored ? JSON.parse(stored) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    localStorage.setItem("watchtracker_ratings", JSON.stringify(ratings));
  }, [ratings]);

  const setRating = useCallback((id: number, rating: number) => {
    setRatings(prev => ({ ...prev, [id]: rating }));
  }, []);

  return [ratings, setRating] as const;
}
