import { useState, useMemo } from "react";
import { ALL_MEDIA } from "@/data/media";
import { MediaItem, TabType } from "@/types/media";
import { useWatchlist, useWatched, useRatings } from "@/hooks/useMediaStore";
import { useApiMedia } from "@/hooks/useApiMedia";
import Header from "@/components/Header";
import GenreFilter from "@/components/GenreFilter";
import MediaGrid from "@/components/MediaGrid";
import DetailModal from "@/components/DetailModal";
import { Loader2 } from "lucide-react";

const Index = () => {
  const [activeTab, setActiveTab] = useState<TabType>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);

  const [watchlist, addToWatchlist, removeFromWatchlist] = useWatchlist();
  const [watched, addToWatched, removeFromWatched] = useWatched();
  const [ratings, setRating] = useRatings();

  const { items: filteredItems, loading, error, loadMore, hasMore } = useApiMedia(
    activeTab,
    searchQuery,
    selectedGenres,
    watchlist,
    watched
  );

  const toggleGenre = (genre: string) => {
    setSelectedGenres(prev =>
      prev.includes(genre) ? prev.filter(g => g !== genre) : [...prev, genre]
    );
  };

  const emptyMessages: Record<TabType, string> = {
    all: "No results found",
    movies: "No movies found",
    anime: "No anime found",
    trending: "No trending items found",
    watchlist: "Your watchlist is empty",
    watched: "You haven't watched anything yet",
  };

  const handleToggleWatchlist = () => {
    if (!selectedItem) return;
    if (watchlist.has(selectedItem.id)) {
      removeFromWatchlist(selectedItem.id);
    } else {
      addToWatchlist(selectedItem.id);
    }
  };

  const handleToggleWatched = () => {
    if (!selectedItem) return;
    if (watched.has(selectedItem.id)) {
      removeFromWatched(selectedItem.id);
    } else {
      addToWatched(selectedItem.id);
      if (watchlist.has(selectedItem.id)) {
        removeFromWatchlist(selectedItem.id);
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="container mx-auto px-4 py-6">
        {!["watchlist", "watched"].includes(activeTab) && (
          <div className="mb-4">
            <GenreFilter selected={selectedGenres} onToggle={toggleGenre} />
          </div>
        )}

        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-muted-foreground">
            {loading ? "Loading..." : `${filteredItems.length} ${filteredItems.length === 1 ? "title" : "titles"}`}
          </p>
          <div className="flex items-center gap-3">
            {error && (
              <p className="text-xs text-destructive">{error}</p>
            )}
            {selectedGenres.length > 0 && (
              <button
                onClick={() => setSelectedGenres([])}
                className="text-xs text-primary hover:underline"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>

        {loading && filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <p className="text-sm text-muted-foreground mt-3">Fetching content...</p>
          </div>
        ) : (
          <>
            <MediaGrid
              items={filteredItems}
              watchlist={watchlist}
              watched={watched}
              onItemClick={setSelectedItem}
              emptyMessage={emptyMessages[activeTab]}
            />

            {hasMore && !loading && filteredItems.length > 0 && (
              <div className="flex justify-center mt-8">
                <button
                  onClick={loadMore}
                  className="px-6 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors"
                >
                  Load More
                </button>
              </div>
            )}

            {loading && filteredItems.length > 0 && (
              <div className="flex justify-center mt-6">
                <Loader2 className="w-6 h-6 text-primary animate-spin" />
              </div>
            )}
          </>
        )}
      </main>

      <DetailModal
        item={selectedItem}
        open={!!selectedItem}
        onClose={() => setSelectedItem(null)}
        isWatchlisted={selectedItem ? watchlist.has(selectedItem.id) : false}
        isWatched={selectedItem ? watched.has(selectedItem.id) : false}
        userRating={selectedItem ? ratings[selectedItem.id] : undefined}
        onToggleWatchlist={handleToggleWatchlist}
        onToggleWatched={handleToggleWatched}
        onRate={(r) => selectedItem && setRating(selectedItem.id, r)}
      />
    </div>
  );
};

export default Index;
