import { MediaItem } from "@/types/media";

const JIKAN_BASE = "https://api.jikan.moe/v4";
const TVMAZE_BASE = "https://api.tvmaze.com";

interface JikanAnime {
  mal_id: number;
  title: string;
  year: number | null;
  score: number | null;
  genres: { name: string }[];
  images: { jpg: { large_image_url: string } };
  synopsis: string | null;
  duration: string | null;
  studios: { name: string }[];
  status: string;
}

interface TVMazeShow {
  id: number;
  name: string;
  premiered: string | null;
  rating: { average: number | null };
  genres: string[];
  image: { medium: string; original: string } | null;
  summary: string | null;
  runtime: number | null;
  network: { name: string } | null;
  status: string;
}

function stripHtml(html: string | null): string {
  if (!html) return "No synopsis available.";
  return html.replace(/<[^>]*>/g, "").trim();
}

function mapJikanToMedia(anime: JikanAnime): MediaItem {
  return {
    id: anime.mal_id + 100000, // offset to avoid ID collisions with TVMaze
    title: anime.title,
    year: anime.year ?? new Date().getFullYear(),
    rating: anime.score ?? 0,
    genre: anime.genres.map((g) => g.name),
    type: "anime",
    poster: anime.images.jpg.large_image_url,
    plot: anime.synopsis ?? "No synopsis available.",
    runtime: anime.duration ?? "24min/ep",
    director: anime.studios.map((s) => s.name).join(", ") || "Unknown Studio",
    cast: [],
    trending: true,
  };
}

function mapTVMazeToMedia(show: TVMazeShow): MediaItem {
  return {
    id: show.id,
    title: show.name,
    year: show.premiered ? parseInt(show.premiered.substring(0, 4)) : new Date().getFullYear(),
    rating: show.rating.average ?? 0,
    genre: show.genres.length > 0 ? show.genres : ["Drama"],
    type: "movie", // TVMaze shows treated as "movies/shows"
    poster: show.image?.medium ?? "/placeholder.svg",
    plot: stripHtml(show.summary),
    runtime: show.runtime ? `${show.runtime}min` : "N/A",
    director: show.network?.name ?? "Unknown",
    cast: [],
    trending: true,
  };
}

// Rate limiter for Jikan (3 req/sec limit)
let lastJikanCall = 0;
async function jikanFetch(url: string): Promise<Response> {
  const now = Date.now();
  const wait = Math.max(0, 400 - (now - lastJikanCall));
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastJikanCall = Date.now();
  return fetch(url);
}

export async function fetchTrendingAnime(page = 1): Promise<MediaItem[]> {
  try {
    const res = await jikanFetch(`${JIKAN_BASE}/top/anime?page=${page}&limit=25&filter=airing`);
    if (!res.ok) throw new Error(`Jikan API error: ${res.status}`);
    const data = await res.json();
    return (data.data as JikanAnime[]).map(mapJikanToMedia);
  } catch (err) {
    console.error("Failed to fetch trending anime:", err);
    return [];
  }
}

export async function searchAnime(query: string): Promise<MediaItem[]> {
  try {
    const res = await jikanFetch(`${JIKAN_BASE}/anime?q=${encodeURIComponent(query)}&limit=25`);
    if (!res.ok) throw new Error(`Jikan API error: ${res.status}`);
    const data = await res.json();
    return (data.data as JikanAnime[]).map(mapJikanToMedia);
  } catch (err) {
    console.error("Failed to search anime:", err);
    return [];
  }
}

export async function fetchTrendingShows(page = 0): Promise<MediaItem[]> {
  try {
    const res = await fetch(`${TVMAZE_BASE}/shows?page=${page}`);
    if (!res.ok) throw new Error(`TVMaze API error: ${res.status}`);
    const data = (await res.json()) as TVMazeShow[];
    // Sort by rating descending and take top 25
    return data
      .filter((s) => s.rating.average && s.image)
      .sort((a, b) => (b.rating.average ?? 0) - (a.rating.average ?? 0))
      .slice(0, 25)
      .map(mapTVMazeToMedia);
  } catch (err) {
    console.error("Failed to fetch trending shows:", err);
    return [];
  }
}

export async function searchShows(query: string): Promise<MediaItem[]> {
  try {
    const res = await fetch(`${TVMAZE_BASE}/search/shows?q=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error(`TVMaze API error: ${res.status}`);
    const data = (await res.json()) as { score: number; show: TVMazeShow }[];
    return data
      .filter((r) => r.show.image)
      .map((r) => mapTVMazeToMedia(r.show));
  } catch (err) {
    console.error("Failed to search shows:", err);
    return [];
  }
}

export async function fetchAllTrending(): Promise<MediaItem[]> {
  const [shows, anime] = await Promise.all([
    fetchTrendingShows(),
    fetchTrendingAnime(),
  ]);
  return [...shows, ...anime];
}
