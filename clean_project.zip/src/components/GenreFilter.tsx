import { GENRES } from "@/types/media";

interface GenreFilterProps {
  selected: string[];
  onToggle: (genre: string) => void;
}

const GenreFilter = ({ selected, onToggle }: GenreFilterProps) => {
  return (
    <div className="flex gap-2 overflow-x-auto scrollbar-hide py-2">
      {GENRES.map(genre => (
        <button
          key={genre}
          onClick={() => onToggle(genre)}
          className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-all border ${
            selected.includes(genre)
              ? "bg-primary text-primary-foreground border-primary"
              : "bg-secondary text-secondary-foreground border-border hover:border-primary/50"
          }`}
        >
          {genre}
        </button>
      ))}
    </div>
  );
};

export default GenreFilter;
