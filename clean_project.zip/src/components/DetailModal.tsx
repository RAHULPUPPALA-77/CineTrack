import { MediaItem } from "@/types/media";
import { Star, Bookmark, BookmarkCheck, Eye, EyeOff, X, Clock, Film, Users } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface DetailModalProps {
  item: MediaItem | null;
  open: boolean;
  onClose: () => void;
  isWatchlisted: boolean;
  isWatched: boolean;
  userRating: number | undefined;
  onToggleWatchlist: () => void;
  onToggleWatched: () => void;
  onRate: (rating: number) => void;
}

const DetailModal = ({
  item, open, onClose,
  isWatchlisted, isWatched, userRating,
  onToggleWatchlist, onToggleWatched, onRate
}: DetailModalProps) => {
  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden bg-card border-border gap-0">
        {/* Header image */}
        <div className="relative h-48 sm:h-64 overflow-hidden">
          <img
            src={item.poster}
            alt={item.title}
            className="w-full h-full object-cover object-top blur-sm scale-110 opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/60 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4 flex gap-4 items-end">
            <img
              src={item.poster}
              alt={item.title}
              className="w-24 sm:w-32 rounded-lg shadow-xl border-2 border-border"
              onError={(e) => { (e.target as HTMLImageElement).src = "/placeholder.svg"; }}
            />
            <div className="flex-1 min-w-0">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-foreground truncate">{item.title}</h2>
              <div className="flex flex-wrap items-center gap-2 mt-1 text-sm text-muted-foreground">
                <span>{item.year}</span>
                <span>·</span>
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{item.runtime}</span>
                <span>·</span>
                <span className="flex items-center gap-1 text-accent"><Star className="w-3 h-3" fill="currentColor" />{item.rating}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 sm:p-6 space-y-4">
          {/* Action buttons */}
          <div className="flex flex-wrap gap-2">
            <Button
              variant={isWatchlisted ? "default" : "outline"}
              size="sm"
              onClick={onToggleWatchlist}
              className={isWatchlisted ? "bg-accent text-accent-foreground hover:bg-accent/80" : ""}
            >
              {isWatchlisted ? <BookmarkCheck className="w-4 h-4 mr-1.5" /> : <Bookmark className="w-4 h-4 mr-1.5" />}
              {isWatchlisted ? "In Watchlist" : "Add to Watchlist"}
            </Button>
            <Button
              variant={isWatched ? "default" : "outline"}
              size="sm"
              onClick={onToggleWatched}
              className={isWatched ? "bg-success text-foreground hover:bg-success/80" : ""}
            >
              {isWatched ? <Eye className="w-4 h-4 mr-1.5" /> : <EyeOff className="w-4 h-4 mr-1.5" />}
              {isWatched ? "Watched" : "Mark Watched"}
            </Button>
          </div>

          {/* User rating */}
          <div>
            <p className="text-xs text-muted-foreground mb-1">Your Rating</p>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  onClick={() => onRate(star)}
                  className="transition-transform hover:scale-125"
                >
                  <Star
                    className={`w-5 h-5 ${userRating && star <= userRating ? "text-accent" : "text-muted-foreground/30"}`}
                    fill={userRating && star <= userRating ? "currentColor" : "none"}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Genres */}
          <div className="flex flex-wrap gap-1.5">
            {item.genre.map(g => (
              <span key={g} className="text-xs px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground">{g}</span>
            ))}
          </div>

          {/* Plot */}
          <p className="text-sm text-muted-foreground leading-relaxed">{item.plot}</p>

          {/* Meta */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div className="flex items-start gap-2">
              <Film className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground">Director</p>
                <p className="text-foreground">{item.director}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Users className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-muted-foreground">Cast</p>
                <p className="text-foreground">{item.cast.join(", ")}</p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DetailModal;
