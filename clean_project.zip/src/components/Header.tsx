import { TabType } from "@/types/media";
import { Search, X, Flame, Bookmark, Eye, Film, Tv, LayoutGrid } from "lucide-react";
import { useState } from "react";

interface HeaderProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
  { id: "all", label: "All", icon: <LayoutGrid className="w-4 h-4" /> },
  { id: "movies", label: "Movies", icon: <Film className="w-4 h-4" /> },
  { id: "anime", label: "Anime", icon: <Tv className="w-4 h-4" /> },
  { id: "trending", label: "Trending", icon: <Flame className="w-4 h-4" /> },
  { id: "watchlist", label: "Watchlist", icon: <Bookmark className="w-4 h-4" /> },
  { id: "watched", label: "Watched", icon: <Eye className="w-4 h-4" /> },
];

const Header = ({ activeTab, onTabChange, searchQuery, onSearchChange }: HeaderProps) => {
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 glass border-b border-border/50">
      <div className="container mx-auto px-4">
        {/* Top row */}
        <div className="flex items-center justify-between h-14">
          <h1 className="font-display font-bold text-lg sm:text-xl text-foreground tracking-tight">
            Watch<span className="text-primary">Tracker</span>
          </h1>

          {/* Desktop search */}
          <div className="hidden sm:flex items-center relative w-72">
            <Search className="absolute left-3 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search movies & anime..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-8 py-2 rounded-lg bg-secondary text-sm text-foreground placeholder:text-muted-foreground border border-border focus:border-primary focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button onClick={() => onSearchChange("")} className="absolute right-2 text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Mobile search toggle */}
          <button
            className="sm:hidden p-2 text-muted-foreground hover:text-foreground"
            onClick={() => setSearchOpen(!searchOpen)}
          >
            <Search className="w-5 h-5" />
          </button>
        </div>

        {/* Mobile search bar */}
        {searchOpen && (
          <div className="sm:hidden pb-3 animate-fade-in">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                autoFocus
                className="w-full pl-9 pr-8 py-2 rounded-lg bg-secondary text-sm text-foreground placeholder:text-muted-foreground border border-border focus:border-primary focus:outline-none"
              />
              {searchQuery && (
                <button onClick={() => onSearchChange("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground">
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Tabs */}
        <nav className="flex gap-1 overflow-x-auto scrollbar-hide pb-2 -mx-1 px-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;
