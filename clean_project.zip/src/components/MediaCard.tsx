import { MediaItem } from "@/types/media";
import { Star, Bookmark, Eye } from "lucide-react";

interface MediaCardProps {
  item: MediaItem;
  isWatchlisted: boolean;
  isWatched: boolean;
  onClick: () => void;
}

const MediaCard = ({ item, isWatchlisted, isWatched, onClick }: MediaCardProps) => {
  return (
    <div
      className="group relative rounded-lg overflow-hidden cursor-pointer hover-lift card-shine bg-card"
      onClick={onClick}
      style={{ animationDelay: `${Math.random() * 0.2}s` }}
    >
      <div className="aspect-[2/3] relative overflow-hidden">
        <img
          src={item.poster}
          alt={item.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "/placeholder.svg";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Status badges */}
        <div className="absolute top-2 right-2 flex flex-col gap-1">
          {isWatchlisted && (
            <span className="bg-accent/90 p-1.5 rounded-md">
              <Bookmark className="w-3.5 h-3.5 text-accent-foreground" fill="currentColor" />
            </span>
          )}
          {isWatched && (
            <span className="bg-success/90 p-1.5 rounded-md">
              <Eye className="w-3.5 h-3.5 text-foreground" />
            </span>
          )}
        </div>

        {/* Rating badge */}
        <div className="absolute top-2 left-2 flex items-center gap-1 bg-background/80 backdrop-blur-sm px-2 py-0.5 rounded-md">
          <Star className="w-3 h-3 text-accent" fill="currentColor" />
          <span className="text-xs font-semibold text-foreground">{item.rating}</span>
        </div>

        {/* Type badge */}
        <div className="absolute bottom-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <span className="text-[10px] font-bold uppercase tracking-wider bg-primary/90 text-primary-foreground px-2 py-0.5 rounded">
            {item.type}
          </span>
        </div>
      </div>

      <div className="p-3">
        <h3 className="font-display font-semibold text-sm text-foreground truncate">{item.title}</h3>
        <p className="text-xs text-muted-foreground mt-0.5">{item.year} · {item.genre.slice(0, 2).join(", ")}</p>
      </div>
    </div>
  );
};

export default MediaCard;
