import { MediaItem } from "@/types/media";
import MediaCard from "./MediaCard";

interface MediaGridProps {
  items: MediaItem[];
  watchlist: Set<number>;
  watched: Set<number>;
  onItemClick: (item: MediaItem) => void;
  emptyMessage?: string;
}

const MediaGrid = ({ items, watchlist, watched, onItemClick, emptyMessage = "No items found" }: MediaGridProps) => {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
        <p className="text-lg font-display">{emptyMessage}</p>
        <p className="text-sm mt-1">Try adjusting your filters or search</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
      {items.map((item, i) => (
        <div key={item.id} className="animate-fade-in" style={{ animationDelay: `${i * 0.03}s`, animationFillMode: "both" }}>
          <MediaCard
            item={item}
            isWatchlisted={watchlist.has(item.id)}
            isWatched={watched.has(item.id)}
            onClick={() => onItemClick(item)}
          />
        </div>
      ))}
    </div>
  );
};

export default MediaGrid;
