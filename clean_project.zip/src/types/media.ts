export interface MediaItem {
  id: number;
  title: string;
  year: number;
  rating: number;
  genre: string[];
  type: "movie" | "anime";
  poster: string;
  backdrop?: string;
  plot: string;
  runtime: string;
  director: string;
  cast: string[];
  trending?: boolean;
}

export type TabType = "all" | "movies" | "anime" | "watchlist" | "watched" | "trending";

export const GENRES = [
  "Action", "Adventure", "Comedy", "Drama", "Fantasy",
  "Horror", "Mystery", "Romance", "Sci-Fi", "Thriller",
  "Slice of Life", "Mecha", "Supernatural", "Sports"
] as const;
